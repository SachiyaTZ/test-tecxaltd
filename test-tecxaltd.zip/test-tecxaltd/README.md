Install Dependencies:

    npm install

Run the Application in Development Mode:

    npm run dev
