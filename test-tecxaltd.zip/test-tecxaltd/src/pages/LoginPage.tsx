import React from 'react'
import LoginForm from '../layout/login/loginForm'

const LoginPage = () => {
  return (
    <div>
        <LoginForm/>
    </div>
  )
}

export default LoginPage