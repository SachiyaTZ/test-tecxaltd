import React from 'react'

const NotFoundPage:React.FC = () => {
  return (
    <div>NotFoundPage</div>
  )
}

export default NotFoundPage